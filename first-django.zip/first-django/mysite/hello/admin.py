from django.contrib import admin

# Register your models here.
python manage.py startapp hello